public class App {
    public static void main(String[] args) throws Exception {
        

        // Câu 1
        // Diem a = new Diem();
        // Diem b = new Diem();
        // a.setDiem(4, 6);
        // b.setDiem(6, 3);
        // System.out.println(a);
    
        // System.out.println(a.tinhKhoangCach(b));

        // Câu 2
        // DoanThang x = new DoanThang();
        // x.setDiem1(4, 5);
        // x.setDiem2(7,5);
        // System.out.println(x);
        // System.out.println("Do dai Doan Thang: "+x.doDaiDoanThang());

        // System.out.println("Toa do Trung Diem: "+x.toDoTrungDiem());
        // DoanThang y = new DoanThang();
        // y.setDiem1(4, 4);
        // y.setDiem2(7, 4);
        // System.out.println("Doan Thang AB co Song Song voi CD ? :"+x.ktSongSong(y));

        // Câu 3
        // HinhChuNhat hcn = new HinhChuNhat();
        // hcn.setDiemUpLeft(0,6);
        // hcn.setDiemDnRight(6, 0);
        // System.out.println("Dien tich hcn: "+hcn.tinhDienTich());
        // System.out.println("Chu vi hcn: "+hcn.tinhChuVi());
        // System.out.println(hcn);

        // Câu 4

        QLHocVien a = new QLHocVien();
        a.themHocVien();
        a.themHocVien();
        a.themHocVien();
        a.getListHocVien();
        a.dienDiemSV();
        a.xemThongTinHocVien();
        a.xoaHocVien2();
        a.getListHocVien();
        a.xemThongTinHocVien2();
        
    }
}
